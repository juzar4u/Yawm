﻿CKEDITOR.plugins.setLang( 'lineheight', 'en', {
	fontSize: {
		label: 'lineheight',
		voiceLabel: 'line-height',
		panelTitle: 'line-height'
	},
	label: 'lineheight',
	panelTitle: 'line-height',
	voiceLabel: 'line-height'
} );
